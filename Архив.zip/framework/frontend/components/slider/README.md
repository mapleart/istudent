# Компонент slider
