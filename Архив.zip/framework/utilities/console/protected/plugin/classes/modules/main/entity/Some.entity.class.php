<?php

class PluginExample_ModuleMain_EntitySome extends EntityORM
{

}