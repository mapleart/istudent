<?php

/**
 * Обработчик блока Main
 */
class PluginExample_BlockMain extends Block
{
    public function Exec()
    {

    }
}