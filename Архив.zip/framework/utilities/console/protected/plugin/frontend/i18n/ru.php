<?php
/**
 * Русский языковой файл плагина
 * Пример ниже соответствует переменной в шаблоне {$aLang.plugin.abcplugin.name}
 */
return array(
    'name' => 'текст',

    'config'          => array(
        'per_page'       => array(
            'name'        => 'Количество элементов на страницу',
            'description' => '',
        ),
    ),
    'config_sections' => array(
        'one' => 'Первый раздел настроек',
    ),
);