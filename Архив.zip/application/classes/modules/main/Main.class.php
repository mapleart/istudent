<?php

class ModuleMain extends Module
{

    /**
     * Инициализация
     */
    public function Init()
    {

    }
}