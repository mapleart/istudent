<?php

class ModuleDocument_MapperDocument extends Mapper {



}