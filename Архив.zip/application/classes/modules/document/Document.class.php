<?php

class ModuleDocument extends ModuleORM {

    const DOCUMENT_NEW=0;
	private $oMapper = null;



	public function Init() {
		/*
		 * orm требует этого
		 */
		parent::Init();
		$this->oMapper = Engine::GetMapper(__CLASS__);
	}


}