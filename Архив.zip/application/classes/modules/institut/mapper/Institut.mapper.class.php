<?php

class ModuleInstitut_MapperInstitut extends Mapper {



}