<?php

class ModuleGroup_MapperGroup extends Mapper {



}