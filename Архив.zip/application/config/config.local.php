<?php
/**
 * Настройки для локального сервера.
 * Для использования - переименовать файл в config.local.php
 * Именно в этом файле необходимо переопределять все настройки конфига
 */

/**
 * Настройка базы данных
 */
$config['db']['params']['host'] = 'localhost';
$config['db']['params']['port'] = '8889';
$config['db']['params']['user'] = 'root';
$config['db']['params']['pass'] = 'root';
$config['db']['params']['type']   = 'mysqli';
$config['db']['params']['dbname'] = 'student';
$config['db']['table']['prefix'] = 'prefix_';

/**
 * Если необходимо установить движек в директорию(не корень сайта) то следует сделать так:
 * $config['path']['root']['web']    = 'http://'.$_SERVER['HTTP_HOST'].'/subdir';
 * и увеличить значение $config['path']['offset_request_url'] на число вложенных директорий,
 * например, для директории первой вложенности www.site.ru/livestreet/ поставить значение равное 1
 */
$config['path']['root']['web'] = 'http://student:8888/';
$config['path']['offset_request_url'] = 0;

$config['module']['asset']['css']['merge'] = false;
$config['module']['asset']['js']['merge'] = false;



$config['sys']['mail']['type'] = 'mail';                 // Какой тип отправки использовать
$config['sys']['mail']['from_email'] = 'mapleart@yandex.ru';      // Мыло с которого отправляются все уведомления
$config['sys']['mail']['from_name'] = 'Личный кабинет Я.Студент';  // Имя с которого отправляются все уведомления
$config['sys']['mail']['charset'] = 'UTF-8';                // Какую кодировку использовать в письмах
$config['sys']['mail']['smtp']['host'] = 'smtp.yandex.ru';            // Настройки SMTP - хост
$config['sys']['mail']['smtp']['port'] = 465;                     // Настройки SMTP - порт
$config['sys']['mail']['smtp']['user'] = 'mapleart@yandex.ru';                     // Настройки SMTP - пользователь
$config['sys']['mail']['smtp']['password'] = 'z183rs4w';                     // Настройки SMTP - пароль
$config['sys']['mail']['smtp']['secure'] = 'ssl';                     // Настройки SMTP - протокол шифрования: tls, ssl
$config['sys']['mail']['smtp']['auth'] = true;                   // Использовать авторизацию при отправке
$config['sys']['mail']['dkim'] = array(
    'selector'   => '', // DKIM selector
    'identity'   => '', // DKIM Identity, обычно емайл адрес с которого отправляются письма
    'passphrase' => '', // DKIM passphrase, пароль для приватного ключа (если задан)
    'domain'     => '', // DKIM signing domain name
    'private'    => '', // DKIM private key file path, полный серверный путь до файла с приватным ключом
);

$config['view']['skin']        = 'student';

return $config;