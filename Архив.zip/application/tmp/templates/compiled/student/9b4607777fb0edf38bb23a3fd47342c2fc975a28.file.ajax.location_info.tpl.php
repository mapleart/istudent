<?php /* Smarty version Smarty-3.1.13, created on 2017-12-02 01:12:37
         compiled from "/Users/aleksejmalyskin/Desktop/student/application/frontend/skin/student/ajax.location_info.tpl" */ ?>
<?php /*%%SmartyHeaderCode:18700431785a21d3d5428b22-94814238%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '9b4607777fb0edf38bb23a3fd47342c2fc975a28' => 
    array (
      0 => '/Users/aleksejmalyskin/Desktop/student/application/frontend/skin/student/ajax.location_info.tpl',
      1 => 1512166353,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '18700431785a21d3d5428b22-94814238',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'oMap' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_5a21d3d55cfa07_53088451',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5a21d3d55cfa07_53088451')) {function content_5a21d3d55cfa07_53088451($_smarty_tpl) {?><?php if ($_smarty_tpl->tpl_vars['oMap']->value){?>
    <div class="marker-info">
        <div class=" scrollbar-outer scrollbar-marker">
            <h2 class="marker-title"><?php echo $_smarty_tpl->tpl_vars['oMap']->value->getTitle();?>
</h2>
            <img src="<?php echo $_smarty_tpl->tpl_vars['oMap']->value->getPhoto();?>
">
            <div class="marker-description">
                <?php echo $_smarty_tpl->tpl_vars['oMap']->value->getDescription();?>

            </div>
            <hr>
            <div class="marker-description" >
                <?php echo $_smarty_tpl->tpl_vars['oMap']->value->getAddress();?>

            </div>
            <hr>

            <h3 class="marker-phone"><?php echo $_smarty_tpl->tpl_vars['oMap']->value->getPhone();?>
</h3>

            <div class="contacts">
                <?php if ($_smarty_tpl->tpl_vars['oMap']->value->getSite()){?>
                    <div class="">
                        <div class="title">Сайт</div>
                        <div class="value"><a href="<?php echo $_smarty_tpl->tpl_vars['oMap']->value->getSite();?>
"><?php echo $_smarty_tpl->tpl_vars['oMap']->value->getSite();?>
</a></div>
                    </div>
                <?php }?>
                <?php if ($_smarty_tpl->tpl_vars['oMap']->value->getMail()){?>
                    <div class="">
                        <div class="title">Почта</div>
                        <div class="value"><a href="mailto:<?php echo $_smarty_tpl->tpl_vars['oMap']->value->getMail();?>
"><?php echo $_smarty_tpl->tpl_vars['oMap']->value->getMail();?>
</a></div>
                    </div>
                <?php }?>

                <?php if ($_smarty_tpl->tpl_vars['oMap']->value->getSocialVk()){?>
                    <div class="">
                        <div class="title">Вконтакте</div>
                        <div class="value"><?php echo $_smarty_tpl->tpl_vars['oMap']->value->getSocialRedirectVk();?>
</div>
                    </div>
                <?php }?>

                <?php if ($_smarty_tpl->tpl_vars['oMap']->value->getSocialFb()){?>
                    <div class="">
                        <div class="title">FaceBook</div>
                        <div class="value"><?php echo $_smarty_tpl->tpl_vars['oMap']->value->getSocialRedirectFb();?>
</div>
                    </div>
                <?php }?>
                <?php if ($_smarty_tpl->tpl_vars['oMap']->value->getSocialOk()){?>
                    <div class="">
                        <div class="title">Одноклассники</div>
                        <div class="value"><?php echo $_smarty_tpl->tpl_vars['oMap']->value->getSocialRedirectOk();?>
</div>
                    </div>
                <?php }?>
                <?php if ($_smarty_tpl->tpl_vars['oMap']->value->getSocialTw()){?>
                    <div class="">
                        <div class="title">Twitter</div>
                        <div class="value"><?php echo $_smarty_tpl->tpl_vars['oMap']->value->getSocialRedirectTw();?>
</div>
                    </div>
                <?php }?>

            </div>
            <hr>


        </div>

    </div>


<?php }?>
<style>


</style><?php }} ?>