<?php /* Smarty version Smarty-3.1.13, created on 2017-12-02 04:34:00
         compiled from "/Users/aleksejmalyskin/Desktop/student/application/frontend/skin/student/actions/ActionAdmin/groups/list.tpl" */ ?>
<?php /*%%SmartyHeaderCode:4256960155a217db2cdcf15-25696790%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '5a350bf3b17eb0bddae399c7cb865795e0d970b0' => 
    array (
      0 => '/Users/aleksejmalyskin/Desktop/student/application/frontend/skin/student/actions/ActionAdmin/groups/list.tpl',
      1 => 1512177495,
      2 => 'file',
    ),
    'b7a3bf5ca8819a460e9bc0b15d9b8a3aeba50234' => 
    array (
      0 => '/Users/aleksejmalyskin/Desktop/student/application/frontend/skin/student/layouts/layout.base.tpl',
      1 => 1512166714,
      2 => 'file',
    ),
    '4b89f8c62b4b86de1891b84d2cd4ba01edf0b75f' => 
    array (
      0 => '/Users/aleksejmalyskin/Desktop/student/framework/frontend/components/layout/layout.tpl',
      1 => 1512138364,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '4256960155a217db2cdcf15-25696790',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_5a217db3124fa4_26956401',
  'variables' => 
  array (
    'lang' => 0,
    'rtl' => 0,
    'sHtmlDescription' => 0,
    'sHtmlKeywords' => 0,
    'sHtmlRobots' => 0,
    'sHtmlTitle' => 0,
    'aHtmlRssAlternate' => 0,
    'sHtmlCanonical' => 0,
    'aHtmlHeadFiles' => 0,
    'LIVESTREET_SECURITY_KEY' => 0,
    'sAction' => 0,
    'aRouter' => 0,
    'sPage' => 0,
    'sPath' => 0,
    'LS' => 0,
    'oUserCurrent' => 0,
    'component' => 0,
    'mods' => 0,
    'classes' => 0,
    'attributes' => 0,
    'sLayoutAfter' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5a217db3124fa4_26956401')) {function content_5a217db3124fa4_26956401($_smarty_tpl) {?><?php if (!is_callable('smarty_function_component_define_params')) include '/Users/aleksejmalyskin/Desktop/student/framework/classes/modules/viewer/plugs/function.component_define_params.php';
if (!is_callable('smarty_function_cfg')) include '/Users/aleksejmalyskin/Desktop/student/framework/classes/modules/viewer/plugs/function.cfg.php';
if (!is_callable('smarty_function_router')) include '/Users/aleksejmalyskin/Desktop/student/framework/classes/modules/viewer/plugs/function.router.php';
if (!is_callable('smarty_function_json')) include '/Users/aleksejmalyskin/Desktop/student/framework/classes/modules/viewer/plugs/function.json.php';
if (!is_callable('smarty_function_show_blocks')) include '/Users/aleksejmalyskin/Desktop/student/framework/classes/modules/viewer/plugs/function.show_blocks.php';
if (!is_callable('smarty_function_hook')) include '/Users/aleksejmalyskin/Desktop/student/framework/classes/modules/viewer/plugs/function.hook.php';
if (!is_callable('smarty_function_cmods')) include '/Users/aleksejmalyskin/Desktop/student/framework/classes/modules/viewer/plugs/function.cmods.php';
if (!is_callable('smarty_function_cattr')) include '/Users/aleksejmalyskin/Desktop/student/framework/classes/modules/viewer/plugs/function.cattr.php';
if (!is_callable('smarty_function_component')) include '/Users/aleksejmalyskin/Desktop/student/framework/classes/modules/viewer/plugs/function.component.php';
if (!is_callable('smarty_function_add_block')) include '/Users/aleksejmalyskin/Desktop/student/framework/classes/modules/viewer/plugs/function.add_block.php';
?>
<!doctype html>

<?php $_smarty_tpl->tpl_vars['component'] = new Smarty_variable('layout', null, 0);?>
<?php echo smarty_function_component_define_params(array('params'=>array('mods','classes','attributes')),$_smarty_tpl);?>



    <?php $_smarty_tpl->tpl_vars['rtl'] = new Smarty_variable(Config::Get('view.rtl') ? 'dir="rtl"' : '', null, 0);?>
    <?php $_smarty_tpl->tpl_vars['lang'] = new Smarty_variable(Config::Get('lang.current'), null, 0);?>

    <?php $_smarty_tpl->tpl_vars['layoutShowSidebar'] = new Smarty_variable((($tmp = @$_smarty_tpl->tpl_vars['layoutShowSidebar']->value)===null||$tmp==='' ? true : $tmp), null, 0);?>
    <?php $_smarty_tpl->tpl_vars['layoutShowSystemMessages'] = new Smarty_variable((($tmp = @$_smarty_tpl->tpl_vars['layoutShowSystemMessages']->value)===null||$tmp==='' ? true : $tmp), null, 0);?>


<!--[if lt IE 7]> <html class="no-js ie6 oldie" lang="<?php echo $_smarty_tpl->tpl_vars['lang']->value;?>
" <?php echo $_smarty_tpl->tpl_vars['rtl']->value;?>
> <![endif]-->
<!--[if IE 7]>    <html class="no-js ie7 oldie" lang="<?php echo $_smarty_tpl->tpl_vars['lang']->value;?>
" <?php echo $_smarty_tpl->tpl_vars['rtl']->value;?>
> <![endif]-->
<!--[if IE 8]>    <html class="no-js ie8 oldie" lang="<?php echo $_smarty_tpl->tpl_vars['lang']->value;?>
" <?php echo $_smarty_tpl->tpl_vars['rtl']->value;?>
> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js" lang="<?php echo $_smarty_tpl->tpl_vars['lang']->value;?>
" <?php echo $_smarty_tpl->tpl_vars['rtl']->value;?>
> <!--<![endif]-->

<head prefix="og: https://ogp.me/ns# article: https://ogp.me/ns/article#">
    
        <meta charset="utf-8">

        <meta name="description" content="<?php echo $_smarty_tpl->tpl_vars['sHtmlDescription']->value;?>
">
        <meta name="keywords" content="<?php echo $_smarty_tpl->tpl_vars['sHtmlKeywords']->value;?>
">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="robots" content="<?php echo $_smarty_tpl->tpl_vars['sHtmlRobots']->value;?>
">

        <title><?php echo $_smarty_tpl->tpl_vars['sHtmlTitle']->value;?>
</title>

        
        <?php if ($_smarty_tpl->tpl_vars['aHtmlRssAlternate']->value){?>
            <link rel="alternate" type="application/rss+xml" href="<?php echo $_smarty_tpl->tpl_vars['aHtmlRssAlternate']->value['url'];?>
" title="<?php echo $_smarty_tpl->tpl_vars['aHtmlRssAlternate']->value['title'];?>
">
        <?php }?>

        
        <?php if ($_smarty_tpl->tpl_vars['sHtmlCanonical']->value){?>
            <link rel="canonical" href="<?php echo $_smarty_tpl->tpl_vars['sHtmlCanonical']->value;?>
" />
        <?php }?>

        
        
            
            <?php echo $_smarty_tpl->tpl_vars['aHtmlHeadFiles']->value['css'];?>

        
    <!-- Custom Fonts -->
    <link href='//fonts.googleapis.com/css?family=Open+Sans:300,400,700&amp;subset=latin,cyrillic' rel='stylesheet' type='text/css'>


        <link href="<?php echo smarty_function_cfg(array('_default_short'=>'path.skin.assets.web'),$_smarty_tpl);?>
/images/favicons/favicon.ico?v1" rel="shortcut icon" />

        <script>
            var PATH_ROOT                   = '<?php echo smarty_function_router(array('page'=>'/'),$_smarty_tpl);?>
',PATH_SKIN                   = '<?php echo smarty_function_cfg(array('_default_short'=>'path.skin.web'),$_smarty_tpl);?>
',PATH_FRAMEWORK_FRONTEND     = '<?php echo smarty_function_cfg(array('_default_short'=>'path.framework.frontend.web'),$_smarty_tpl);?>
',PATH_FRAMEWORK_LIBS_VENDOR  = '<?php echo smarty_function_cfg(array('_default_short'=>'path.framework.libs_vendor.web'),$_smarty_tpl);?>
',LIVESTREET_SECURITY_KEY = '<?php echo $_smarty_tpl->tpl_vars['LIVESTREET_SECURITY_KEY']->value;?>
',LANGUAGE                = '<?php echo Config::Get('lang.current');?>
',WYSIWYG                 = <?php if (Config::Get('view.wysiwyg')){?>true<?php }else{ ?>false<?php }?>,ACTION = '<?php echo $_smarty_tpl->tpl_vars['sAction']->value;?>
';var aRouter = [];<?php  $_smarty_tpl->tpl_vars['sPath'] = new Smarty_Variable; $_smarty_tpl->tpl_vars['sPath']->_loop = false;
 $_smarty_tpl->tpl_vars['sPage'] = new Smarty_Variable;
 $_from = $_smarty_tpl->tpl_vars['aRouter']->value; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array');}
foreach ($_from as $_smarty_tpl->tpl_vars['sPath']->key => $_smarty_tpl->tpl_vars['sPath']->value){
$_smarty_tpl->tpl_vars['sPath']->_loop = true;
 $_smarty_tpl->tpl_vars['sPage']->value = $_smarty_tpl->tpl_vars['sPath']->key;
?>aRouter['<?php echo $_smarty_tpl->tpl_vars['sPage']->value;?>
'] = '<?php echo $_smarty_tpl->tpl_vars['sPath']->value;?>
';<?php } ?>
        </script>

        
        <?php echo $_smarty_tpl->tpl_vars['aHtmlHeadFiles']->value['js'];?>



        <script>
            ls.lang.load(<?php echo smarty_function_json(array('var'=>$_smarty_tpl->tpl_vars['LS']->value->Lang_GetLangJs()),$_smarty_tpl);?>
);
            ls.registry.set(<?php echo smarty_function_json(array('var'=>$_smarty_tpl->tpl_vars['LS']->value->Viewer_GetVarsJs()),$_smarty_tpl);?>
);
        </script>

        
    
    
    <?php if ($_smarty_tpl->tpl_vars['layoutShowSidebar']->value){?>
        <?php echo smarty_function_show_blocks(array('group'=>'right','assign'=>'layoutSidebarBlocks'),$_smarty_tpl);?>


        <?php $_smarty_tpl->tpl_vars['layoutSidebarBlocks'] = new Smarty_variable(trim($_smarty_tpl->tpl_vars['layoutSidebarBlocks']->value), null, 0);?>
        <?php $_smarty_tpl->tpl_vars['layoutShowSidebar'] = new Smarty_variable(!!$_smarty_tpl->tpl_vars['layoutSidebarBlocks']->value&&$_smarty_tpl->tpl_vars['layoutShowSidebar']->value, null, 0);?>
    <?php }?>


    <?php echo smarty_function_hook(array('run'=>'html_head_end'),$_smarty_tpl);?>

</head>



<?php if ($_smarty_tpl->tpl_vars['oUserCurrent']->value){?>
    <?php $_smarty_tpl->tpl_vars['mods'] = new Smarty_variable(((string)$_smarty_tpl->tpl_vars['mods']->value)." user-role-user", null, 0);?>

    <?php if ($_smarty_tpl->tpl_vars['oUserCurrent']->value->isAdministrator()){?>
        <?php $_smarty_tpl->tpl_vars['mods'] = new Smarty_variable(((string)$_smarty_tpl->tpl_vars['mods']->value)." user-role-admin", null, 0);?>
    <?php }?>
<?php }else{ ?>
    <?php $_smarty_tpl->tpl_vars['mods'] = new Smarty_variable(((string)$_smarty_tpl->tpl_vars['mods']->value)." user-role-guest", null, 0);?>
<?php }?>

<?php if (!$_smarty_tpl->tpl_vars['oUserCurrent']->value||!$_smarty_tpl->tpl_vars['oUserCurrent']->value->isAdministrator()){?>
    <?php $_smarty_tpl->tpl_vars['mods'] = new Smarty_variable(((string)$_smarty_tpl->tpl_vars['mods']->value)." user-role-not-admin", null, 0);?>
<?php }?>

<?php ob_start();?><?php echo Config::Get('view.skin');?>
<?php $_tmp1=ob_get_clean();?><?php ob_start();?><?php echo Config::Get('view.grid.type');?>
<?php $_tmp2=ob_get_clean();?><?php $_smarty_tpl->tpl_vars['mods'] = new Smarty_variable(((string)$_smarty_tpl->tpl_vars['mods']->value)." template-".$_tmp1." ".$_tmp2, null, 0);?>

<body class="<?php echo $_smarty_tpl->tpl_vars['component']->value;?>
 <?php echo smarty_function_cmods(array('name'=>$_smarty_tpl->tpl_vars['component']->value,'mods'=>$_smarty_tpl->tpl_vars['mods']->value),$_smarty_tpl);?>
 <?php echo $_smarty_tpl->tpl_vars['classes']->value;?>
" <?php echo smarty_function_cattr(array('list'=>$_smarty_tpl->tpl_vars['attributes']->value),$_smarty_tpl);?>
>
    

    

    <!-- Page Content -->
    <div class="container-fluid role-main js-root-container">

        <div class="row">

            <div class="col-sm-3  col-ls-3 role-navbar-wrapper">
                <div class="role-navbar">


                    <div>
                        <?php echo smarty_function_component(array('_default_short'=>'userbar'),$_smarty_tpl);?>

                    </div>

                    <div class="main-nav">
                        <div class="nav-item <?php if ($_smarty_tpl->tpl_vars['sAction']->value=='index'){?>open<?php }?>">
                            <a href="#" data-toggle="main-menu">Личные данные <i class="nav-trigger ion-chevron-down"></i></a>
                            <div class="nav-item-sub">
                                <div class="nav-item">
                                    <a href="<?php echo smarty_function_router(array('page'=>'/'),$_smarty_tpl);?>
">Основная информация </a>
                                </div>
                                <div class="nav-item">
                                    <a href="#">Профиль подготовки</a>
                                </div>
                            </div>
                        </div>

                        <div class="nav-item">
                            <a href="#" data-toggle="main-menu">Учебная деятельность <i class="nav-trigger ion-chevron-down"></i></a>
                            <div class="nav-item-sub">
                                <div class="nav-item">
                                    <a href="#">Рассписание</a>
                                </div>
                                <div class="nav-item">
                                    <a href="#">События</a>
                                </div>

                                <div class="nav-item">
                                    <a href="#">Сообщения</a>
                                </div>

                                <div class="nav-item">
                                    <a href="#">Документы</a>
                                </div>

                                <div class="nav-item">
                                    <a href="#">Библиотечные ресурсы</a>
                                </div>
                            </div>
                        </div>

                        <div class="nav-item">
                            <a href="#" data-toggle="main-menu">Здоровье <i class="nav-trigger ion-chevron-down"></i></a>
                            <div class="nav-item-sub">
                                <div class="nav-item">
                                    <a href="#">Медпункт</a>
                                </div>
                                <div class="nav-item">
                                    <a href="#">Психологическая помощь</a>
                                </div>
                            </div>
                        </div>

                        <div class="nav-item  <?php if ($_smarty_tpl->tpl_vars['sAction']->value=='sport'){?>open<?php }?>">
                            <a href="#" data-toggle="main-menu">Спортивная деятельность <i class="nav-trigger ion-chevron-down"></i></a>
                            <div class="nav-item-sub">
                                <div class="nav-item <?php if ($_smarty_tpl->tpl_vars['sAction']->value=='sport'&&$_smarty_tpl->tpl_vars['sEvent']->value=='gyms'){?>active<?php }?>">
                                    <a href="<?php echo smarty_function_router(array('_default_short'=>'/'),$_smarty_tpl);?>
sport/gyms">Спортивные залы</a>
                                </div>
                                <div class="nav-item">
                                    <a href="#">Мероприятия</a>
                                </div>
                                <div class="nav-item">
                                    <a href="#">Спортивные секции</a>
                                </div>
                            </div>
                        </div>
                        <div class="nav-item   <?php if ($_smarty_tpl->tpl_vars['sAction']->value=='culture'){?>open<?php }?>">
                            <a href="#" data-toggle="main-menu">Культурно-досуговая деятельность <i class="nav-trigger ion-chevron-down"></i></a>
                            <div class="nav-item-sub">
                                <div class="nav-item">
                                    <a href="#">Общественная деятельность</a>
                                </div>
                                <div class="nav-item <?php if ($_smarty_tpl->tpl_vars['sAction']->value=='culture'&&$_smarty_tpl->tpl_vars['sEvent']->value=='dance'){?>active<?php }?>">
                                    <a href="<?php echo smarty_function_router(array('page'=>'culture'),$_smarty_tpl);?>
dance/">Танцевальная студия</a>
                                </div>
                                <div class="nav-item <?php if ($_smarty_tpl->tpl_vars['sAction']->value=='culture'&&$_smarty_tpl->tpl_vars['sEvent']->value=='vocal'){?>active<?php }?>" >
                                    <a href="<?php echo smarty_function_router(array('page'=>'culture'),$_smarty_tpl);?>
vocal/" class="">Вакальная студия</a>
                                </div>
                            </div>
                        </div>

                        <div class="nav-item">
                            <a href="#">Правовое поле</a>
                        </div>

                    </div>
                </div>
            </div>
            <!-- Blog Post Content Column -->
            <div class="col-sm-9 col-lg-9">
                <?php echo smarty_function_hook(array('run'=>'content_begin'),$_smarty_tpl);?>


                
                
                    <h1 class="page-header">
                        
    Управление группами

                    </h1>


                
                    
                    <?php if ($_smarty_tpl->tpl_vars['layoutShowSystemMessages']->value){?>
                        <?php if ($_smarty_tpl->tpl_vars['aMsgError']->value){?>
                            <?php echo smarty_function_component(array('_default_short'=>'alert','text'=>$_smarty_tpl->tpl_vars['aMsgError']->value,'mods'=>'error','close'=>true),$_smarty_tpl);?>

                        <?php }?>

                        <?php if ($_smarty_tpl->tpl_vars['aMsgNotice']->value){?>
                            <?php echo smarty_function_component(array('_default_short'=>'alert','text'=>$_smarty_tpl->tpl_vars['aMsgNotice']->value,'close'=>true),$_smarty_tpl);?>

                        <?php }?>
                    <?php }?>
                

                
    <div class="">
        <a href="<?php echo smarty_function_router(array('page'=>'admin'),$_smarty_tpl);?>
groups/add" class="btn btn-primary">Добавить новый объект</a>
    </div>

    <div id="listGroups">
        <div id="toolbar">
        </div>
        <table class="js-tableGroups"
               data-show-toolbar="false"
               data-show-columns="false"
               data-sort-name="id"
               data-sort-order="desc"
               data-toolbar="#toolbar"
               data-search="false"

               data-show-refresh="false"
               data-show-toggle="false"
               data-show-export="false"
               data-show-pagination-switch="false"

               data-detail-view="false"
               data-minimum-count-columns="2"
               data-pagination="true"
               data-id-field="id"
               data-page-list="[10, 25, 50, 100, ALL]"
               data-page-size="25"
               data-show-footer="false"
               data-side-pagination="server"
        >
            <thead>
            <tr>
                <th data-field="id" data-sortable="true">#ID</th>
                <th data-field="name" data-sortable="false">Название</th>
                <th data-field="name_full" data-sortable="false">Номер</th>
                <th data-field="istitut" data-sortable="false">Институт</th>
                <th data-field="actions" data-formatter="formatterAction" >Действие</th>

            </tr>
            </thead>
        </table>
    </div>

    <script>
        function formatterAction (value, row, index) {
            return '<a href="'+row['edit_url']+'" class="btn btn-primary">Редактировать</a> <a href="#" data-map-id="'+row['id']+'" class="btn btn-danger js-institut-remove">Удалить</a>';
        }
    </script>


                <?php echo smarty_function_hook(array('run'=>'content_end'),$_smarty_tpl);?>


                <!-- Blog Post -->
            </div>

            
            
        </div>
        <!-- /.row -->

        <hr>

        <!-- Footer -->
        <footer>
            
                <?php echo smarty_function_hook(array('run'=>'footer_begin'),$_smarty_tpl);?>

                <div class="row">
                    <div class="col-lg-12">
                        <p>Copyright &copy; Your Website <?php echo date('Y');?>
</p>
                    </div>
                </div>
                <?php echo smarty_function_hook(array('run'=>'footer_end'),$_smarty_tpl);?>

            
        </footer>

    </div>
    <!-- /.container -->

    
    <?php if (!$_smarty_tpl->tpl_vars['oUserCurrent']->value){?>
        <?php echo smarty_function_component(array('_default_short'=>'auth','template'=>'modal'),$_smarty_tpl);?>

    <?php }?>

    
    <?php echo smarty_function_add_block(array('group'=>'toolbar','name'=>'component@toolbar-scrollup.toolbar.scrollup','priority'=>-100),$_smarty_tpl);?>

    
    <?php ob_start();?><?php echo smarty_function_show_blocks(array('group'=>'toolbar'),$_smarty_tpl);?>
<?php $_tmp1=ob_get_clean();?><?php echo smarty_function_component(array('_default_short'=>'toolbar','classes'=>'js-toolbar-default','items'=>$_tmp1),$_smarty_tpl);?>



    <?php echo smarty_function_hook(array('run'=>'body_end'),$_smarty_tpl);?>



    
    

    


    <?php echo $_smarty_tpl->tpl_vars['sLayoutAfter']->value;?>

</body>
</html><?php }} ?>