<?php /* Smarty version Smarty-3.1.13, created on 2017-12-01 20:01:12
         compiled from "/Users/aleksejmalyskin/Desktop/student/application/frontend/components/userbar/userbar.tpl" */ ?>
<?php /*%%SmartyHeaderCode:12020657955a218927a18148-73708594%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'fe49bf1a145bac89bc0c612f0fddda2897177ab3' => 
    array (
      0 => '/Users/aleksejmalyskin/Desktop/student/application/frontend/components/userbar/userbar.tpl',
      1 => 1512147671,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '12020657955a218927a18148-73708594',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_5a218927b71614_32439137',
  'variables' => 
  array (
    'oUserCurrent' => 0,
    'LIVESTREET_SECURITY_KEY' => 0,
  ),
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5a218927b71614_32439137')) {function content_5a218927b71614_32439137($_smarty_tpl) {?><?php if (!is_callable('smarty_function_router')) include '/Users/aleksejmalyskin/Desktop/student/framework/classes/modules/viewer/plugs/function.router.php';
?>
<div class="logo">
    <a href="<?php echo smarty_function_router(array('page'=>'/'),$_smarty_tpl);?>
">Я.<?php if ($_smarty_tpl->tpl_vars['oUserCurrent']->value->isTutor()){?>Староста<?php }else{ ?>Студент<?php }?></a>
</div>


<ul class="nav nav-pills">

    <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="<?php echo smarty_function_router(array('page'=>"/"),$_smarty_tpl);?>
" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <?php echo $_smarty_tpl->tpl_vars['oUserCurrent']->value->getDisplayName();?>

        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
            <?php if ($_smarty_tpl->tpl_vars['oUserCurrent']->value->isAdmin()){?>
                <a href="<?php echo smarty_function_router(array('page'=>'admin'),$_smarty_tpl);?>
"  class="dropdown-item">Управление</a>
            <?php }?>
            <a href="<?php echo smarty_function_router(array('page'=>'auth/logout'),$_smarty_tpl);?>
?security_ls_key=<?php echo $_smarty_tpl->tpl_vars['LIVESTREET_SECURITY_KEY']->value;?>
" class="dropdown-item">Выход</a>
        </div>
    </li>

</ul>
<?php }} ?>