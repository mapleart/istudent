<?php /* Smarty version Smarty-3.1.13, created on 2017-12-01 13:05:08
         compiled from "/Users/aleksejmalyskin/Desktop/student/application/frontend/components/field/field.captcha.tpl" */ ?>
<?php /*%%SmartyHeaderCode:21260837135a212954b8d371-21596656%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c7a2fee662291ff282b070d49ffc02a4c1a549dc' => 
    array (
      0 => '/Users/aleksejmalyskin/Desktop/student/application/frontend/components/field/field.captcha.tpl',
      1 => 1494805594,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '21260837135a212954b8d371-21596656',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'captchaType' => 0,
    'params' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_5a212954bb1061_96945559',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5a212954bb1061_96945559')) {function content_5a212954bb1061_96945559($_smarty_tpl) {?><?php if (!is_callable('smarty_function_component_define_params')) include '/Users/aleksejmalyskin/Desktop/student/framework/classes/modules/viewer/plugs/function.component_define_params.php';
if (!is_callable('smarty_function_component')) include '/Users/aleksejmalyskin/Desktop/student/framework/classes/modules/viewer/plugs/function.component.php';
?>

<?php echo smarty_function_component_define_params(array('params'=>array('label','captchaName','name','captchaType','mods','attributes','classes')),$_smarty_tpl);?>


<?php echo smarty_function_component(array('_default_short'=>'field','template'=>"captcha-".((string)$_smarty_tpl->tpl_vars['captchaType']->value),'params'=>$_smarty_tpl->tpl_vars['params']->value),$_smarty_tpl);?>
<?php }} ?>