<?php /* Smarty version Smarty-3.1.13, created on 2017-12-01 13:07:31
         compiled from "/Users/aleksejmalyskin/Desktop/student/application/frontend/components/auth/auth.reset.tpl" */ ?>
<?php /*%%SmartyHeaderCode:2597362045a2129e35731d6-73813522%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'e3c7b33c801bd75b837b43a9f8f8c403598ebcff' => 
    array (
      0 => '/Users/aleksejmalyskin/Desktop/student/application/frontend/components/auth/auth.reset.tpl',
      1 => 1499105330,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '2597362045a2129e35731d6-73813522',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'modal' => 0,
    'aLang' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_5a2129e35b5195_82023509',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5a2129e35b5195_82023509')) {function content_5a2129e35b5195_82023509($_smarty_tpl) {?><?php if (!is_callable('smarty_function_component_define_params')) include '/Users/aleksejmalyskin/Desktop/student/framework/classes/modules/viewer/plugs/function.component_define_params.php';
if (!is_callable('smarty_function_router')) include '/Users/aleksejmalyskin/Desktop/student/framework/classes/modules/viewer/plugs/function.router.php';
if (!is_callable('smarty_function_component')) include '/Users/aleksejmalyskin/Desktop/student/framework/classes/modules/viewer/plugs/function.component.php';
?>

<?php echo smarty_function_component_define_params(array('params'=>array('modal')),$_smarty_tpl);?>


<form action="<?php echo smarty_function_router(array('page'=>'auth'),$_smarty_tpl);?>
password-reset/" method="post" class="js-form-validate js-auth-reset-form<?php if ($_smarty_tpl->tpl_vars['modal']->value){?>-modal<?php }?>">
    
    <?php echo smarty_function_component(array('_default_short'=>'field','template'=>'email','label'=>$_smarty_tpl->tpl_vars['aLang']->value['auth']['reset']['form']['fields']['mail']['label']),$_smarty_tpl);?>


    <?php echo smarty_function_component(array('_default_short'=>'button','name'=>'submit_reset','mods'=>'primary','text'=>$_smarty_tpl->tpl_vars['aLang']->value['auth']['reset']['form']['fields']['submit']['text']),$_smarty_tpl);?>

</form><?php }} ?>