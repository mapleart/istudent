<?php /* Smarty version Smarty-3.1.13, created on 2017-12-01 20:37:50
         compiled from "/Users/aleksejmalyskin/Desktop/student/application/frontend/components/field/field.hidden.security-key.tpl" */ ?>
<?php /*%%SmartyHeaderCode:17496741895a21936e7c3611-07756600%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'bd8c2b8cfe6871c0678d8448203a398fc245821d' => 
    array (
      0 => '/Users/aleksejmalyskin/Desktop/student/application/frontend/components/field/field.hidden.security-key.tpl',
      1 => 1494805594,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '17496741895a21936e7c3611-07756600',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'LIVESTREET_SECURITY_KEY' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_5a21936e7d2d61_22641469',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5a21936e7d2d61_22641469')) {function content_5a21936e7d2d61_22641469($_smarty_tpl) {?><?php if (!is_callable('smarty_function_component')) include '/Users/aleksejmalyskin/Desktop/student/framework/classes/modules/viewer/plugs/function.component.php';
?>

<?php echo smarty_function_component(array('_default_short'=>'field','template'=>'hidden','name'=>'security_ls_key','value'=>$_smarty_tpl->tpl_vars['LIVESTREET_SECURITY_KEY']->value),$_smarty_tpl);?>
<?php }} ?>