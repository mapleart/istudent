<?php /* Smarty version Smarty-3.1.13, created on 2017-12-01 13:07:31
         compiled from "/Users/aleksejmalyskin/Desktop/student/application/frontend/skin/student/components/userbar/userbar.tpl" */ ?>
<?php /*%%SmartyHeaderCode:310671475a2129e3347193-27790924%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f32cead47d0f5e53abb72af38cb0804827e8b0f5' => 
    array (
      0 => '/Users/aleksejmalyskin/Desktop/student/application/frontend/skin/student/components/userbar/userbar.tpl',
      1 => 1499105330,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '310671475a2129e3347193-27790924',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'oUserCurrent' => 0,
    'LIVESTREET_SECURITY_KEY' => 0,
    'aLang' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_5a2129e33e0f67_41325143',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5a2129e33e0f67_41325143')) {function content_5a2129e33e0f67_41325143($_smarty_tpl) {?><?php if (!is_callable('smarty_function_router')) include '/Users/aleksejmalyskin/Desktop/student/framework/classes/modules/viewer/plugs/function.router.php';
?>
<!-- Navigation -->
<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <div class="container">
        <!-- Brand and toggle get grouped for better mobile display -->
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="<?php echo smarty_function_router(array('page'=>'/'),$_smarty_tpl);?>
"><?php echo Config::Get('view.name');?>
</a>
        </div>
        <!-- Collect the nav links, forms, and other content for toggling -->
        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <?php if ($_smarty_tpl->tpl_vars['oUserCurrent']->value){?>
                <ul class="nav navbar-nav">
                    <li class="dropdown">
                        <a class="dropdown-toggle" href="#" data-toggle="dropdown">
                            <?php echo htmlspecialchars($_smarty_tpl->tpl_vars['oUserCurrent']->value->getDisplayName(), ENT_QUOTES, 'UTF-8', true);?>

                            <span class="caret"></span>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a href="<?php echo $_smarty_tpl->tpl_vars['oUserCurrent']->value->getUrl();?>
">Профиль</a></li>
                            <li><a href="<?php echo $_smarty_tpl->tpl_vars['oUserCurrent']->value->getUrl();?>
">Другое</a></li>
                        </ul>
                    </li>
                    <li>
                        <a href="<?php echo smarty_function_router(array('page'=>'auth/logout'),$_smarty_tpl);?>
?security_ls_key=<?php echo $_smarty_tpl->tpl_vars['LIVESTREET_SECURITY_KEY']->value;?>
"><?php echo $_smarty_tpl->tpl_vars['aLang']->value['auth']['logout'];?>
</a>
                    </li>
                </ul>
            <?php }else{ ?>
                <ul class="nav navbar-nav">
                    <li><a class="js-modal-toggle-login" href="<?php echo smarty_function_router(array('page'=>'auth/login'),$_smarty_tpl);?>
"><?php echo $_smarty_tpl->tpl_vars['aLang']->value['auth']['login']['title'];?>
</a></li>
                    <li><a class="js-modal-toggle-registration" href="<?php echo smarty_function_router(array('page'=>'auth/register'),$_smarty_tpl);?>
"><?php echo $_smarty_tpl->tpl_vars['aLang']->value['auth']['registration']['title'];?>
</a></li>
                </ul>
            <?php }?>
        </div>
        <!-- /.navbar-collapse -->
    </div>
    <!-- /.container -->
</nav><?php }} ?>