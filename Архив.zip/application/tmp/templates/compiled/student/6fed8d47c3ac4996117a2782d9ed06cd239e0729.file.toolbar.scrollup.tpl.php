<?php /* Smarty version Smarty-3.1.13, created on 2017-12-01 13:07:31
         compiled from "/Users/aleksejmalyskin/Desktop/student/application/frontend/components/toolbar-scrollup/toolbar.scrollup.tpl" */ ?>
<?php /*%%SmartyHeaderCode:21123647955a2129e39e3ed0-56106056%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6fed8d47c3ac4996117a2782d9ed06cd239e0729' => 
    array (
      0 => '/Users/aleksejmalyskin/Desktop/student/application/frontend/components/toolbar-scrollup/toolbar.scrollup.tpl',
      1 => 1499105330,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '21123647955a2129e39e3ed0-56106056',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.13',
  'unifunc' => 'content_5a2129e3a12828_29819712',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5a2129e3a12828_29819712')) {function content_5a2129e3a12828_29819712($_smarty_tpl) {?><?php if (!is_callable('smarty_function_lang')) include '/Users/aleksejmalyskin/Desktop/student/framework/classes/modules/viewer/plugs/function.lang.php';
if (!is_callable('smarty_function_component')) include '/Users/aleksejmalyskin/Desktop/student/framework/classes/modules/viewer/plugs/function.component.php';
?>

<?php ob_start();?><?php echo smarty_function_lang(array('_default_short'=>'toolbar.scrollup.title'),$_smarty_tpl);?>
<?php $_tmp1=ob_get_clean();?><?php echo smarty_function_component(array('_default_short'=>'toolbar','template'=>'item','classes'=>'toolbar-item--scrollup js-toolbar-scrollup','attributes'=>array('style'=>'display: none'),'buttons'=>array(array('icon'=>'chevron-up','attributes'=>array('title'=>$_tmp1,'id'=>'toolbar_scrollup')))),$_smarty_tpl);?>
<?php }} ?>